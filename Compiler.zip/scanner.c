// COP 3402 - Systems Software
// 4-14-17 | Austin Peace & Andrew Emery
// Programming Assignment 2 - Scanner

// HEADER.

#include "Compiler.h"

// PROTOTYPES.

char* inReader(FILE* file);
void printBuffer(char* buffer, int length);
int clean(token* lexemes, char* buffer, int buffersize);
void report(token* lexemes, int tokensFlag, int length);
int invalid(char value);
int isLetter(char value);
int isDigit(char value);
void tokenWord(token* lexemes, int* token_index, int word_id, char* buffer);
void tokenNum(token* lexemes, int* token_index, char* buffer, int length);
void tokenSym(token* lexemes, int* token_index, int sym_id, const char* token_name);

// GLOBALS.

const char* errors[4] = {"Variable does not start with letter.", "Number too long.", "Name too long.", "Invalid symbols detected."};
const char* words[RESERVED_WORDS] = {"const", "var", "procedure", "call", "begin", "end", "if", "then", "else", "while", "do", "read", "write", "odd", "int"};
const char symbols[RESERVED_SYMBOLS] = {'+','-','*','/','(',')','=',',','.','<','>',';', ':'};
int* errorcode;

// MAIN PROGRAM.

int scanner(char* filename, int tokensFlag, int* errorFlag) {
    // Local variables.
    int n, length = 0;
    char* sourceBuffer;
    int sourceLength;
    token* lexemes = malloc(MAX_TOKENS*sizeof(token));
    FILE* fp;

    errorcode = calloc(4, sizeof(int));

    // Read input file into code store. If it fails, notify the user.
    fp = fopen(filename, "r");
    if (fp == NULL) {
        printf("\nERROR: Unable to locate/open source file! Check local directory.\n");
        *errorFlag = true;
        return 0;
    }

    // Read the input source file, and populate the buffer with the program's contents.
    sourceBuffer = inReader(fp);
    sourceLength = strlen(sourceBuffer);
    fclose(fp);

    // Print the contents of the entire input file.
    printBuffer(sourceBuffer, sourceLength);

    // Remove invalid characters/tidy up buffered input.
    length = clean(lexemes, sourceBuffer, sourceLength+1);

    // Check for error conditions.
    for (n = 0; n < 4; n++) {
        if (errorcode[n]) {
            printf("\n\nERROR: %s", errors[n]);
            free(sourceBuffer);
            *errorFlag = true;
            return 0;
        }
    }
    // If no errors have been discovered, read finalized input/tokens.
    if (tokensFlag) report(lexemes, tokensFlag, length);

    // Write the tokenization to its own file.
    fp = fopen("tokens.txt", "w");
    for (n = 0; n < length; n++) {
        fprintf(fp, "%d ", lexemes[n].symbol_id);
        if (lexemes[n].symbol_id == identsym || lexemes[n].symbol_id == numbersym) fprintf(fp, "%s ", lexemes[n].name);
    }
    fclose(fp);

    // Tidy up heap memory.
    free(sourceBuffer);
    free(lexemes);
    free(errorcode);

    return length;
}

// FUNCTIONS.
char* inReader(FILE* file) {
    // Local variables.
    int n = 0;
    char* stream = malloc(MAX_SOURCE_FILE*sizeof(char));
    char temp;

    // Read the entire file as a stream of input.
    while ((temp = fgetc(file)) != EOF) {
        stream[n] = temp;
        n++;
    }
    stream[n] = '\0';

    return stream;
}

void printBuffer(char* buffer, int length) {
    // Local variables.
    int n;

    // Print header.
    printf("\nSource Program:\n");

    // Print the entire contents of the designated file.
    for (n = 0; n < length; n++) {
        printf("%c", buffer[n]);
    }

    return;
}

int clean(token* lexemes, char* buffer, int buffersize) {
    // Local variables.
    int n, tracer = 0, numtokens = 0;
    char* tempbuf;

    // Step 1: Clean out all unnecessary components of source file.
    for (n = 0; n+1 < buffersize; n++) {
        // Invisible characters...
        if (invalid(buffer[n])) buffer[n] = ' ';

        // Comments...
        if (buffer[n] == '/' && buffer[n+1] == '*') {

            // Mimic conversion of all following text to empty space.
            while (n+1 < buffersize && !(buffer[n] == '*' && buffer[n+1] == '/')) {
                buffer[n] = ' ';
                n++;
            }
            if (buffer[n] == '*' && buffer[n+1] == '/') {
                buffer[n] = ' ';
                buffer[n+1] = ' ';
            }
        }
    }
    buffer[buffersize-1] = '\0';

    // Step 2: Tokenize clean input.
    while (tracer < buffersize-1) {

        if (buffer[tracer] != ' ') {

            // Case 1: If the first character in the word is a letter.
            if (isLetter(buffer[tracer])) {
                // Allocate temporary buffer.
                tempbuf = malloc(MAX_WORD_SIZE+1*sizeof(char));

                // Generate the full word.
                n = 0;
                while ((n < MAX_WORD_SIZE+1) && (isLetter(buffer[tracer]) || isDigit(buffer[tracer]))) {

                    tempbuf[n] = buffer[tracer];
                    tracer++;
                    n++;
                }
                if (n == MAX_WORD_SIZE+1) {
                    errorcode[2] = true;
                    return numtokens;
                }
                else {
                    tempbuf[n] = '\0';
                }
                // Compare assembled word to reserved. If a match is found, diverge.
                for (n = 0; n < RESERVED_WORDS; n++) {
                    if (strcmp(tempbuf, words[n]) == 0) {
                        tokenWord(lexemes, &numtokens, n, tempbuf);
                        break;
                    }
                }

                // If no match is found, it must be treated as an identifier.
                if (n == RESERVED_WORDS) tokenWord(lexemes, &numtokens, -1, tempbuf);

                // Free the buffer.
                free(tempbuf);

                // If we conclude with <not whitespace>, preemptively decrement tracer.
                //if (buffer[tracer] != ' ') tracer--;

            }

            // Case 2: If the first character in the word is a digit.
            else if (isDigit(buffer[tracer])) {
                // Allocate temporary buffer.
                tempbuf = malloc(MAX_NUM_SIZE+1*sizeof(char));

                // Generate the number.
                n = 0;
                while (n < MAX_NUM_SIZE && isDigit(buffer[tracer])) {

                    tempbuf[n] = buffer[tracer];
                    tracer++;
                    n++;
                }

                // If our number is too large, report the error.
                if (n == MAX_NUM_SIZE) {
                    errorcode[1] = true;
                    return numtokens;
                }

                // If we find a letter in our number sequence, that's an error!
                else if (isLetter(buffer[tracer])) {
                    errorcode[0] = true;
                    return numtokens;
                }
                else tempbuf[n] = '\0';

                // Convert number string to integer (tokenize).
                tokenNum(lexemes, &numtokens, tempbuf, n);

                // Free the buffer.
                free(tempbuf);

                // If we conclude with <not whitespace>, preemptively decrement tracer.
                //if (buffer[tracer] != ' ') tracer--;
            }

            // Case 3: If the first character in the word is a reserved symbol.
            else {

                int errorflag = true;

                // Check the symbol against reserved. Handle special cases.
                for (n = 0; n < RESERVED_SYMBOLS; n++) {
                    if (buffer[tracer] == symbols[n]) {
                        // We know we have some manner of legitimate symbol.
                        errorflag = false;

                        // Unless the next element marks the end of the buffer, do this.
                        if (tracer+1 < buffersize) {
                            switch (buffer[tracer]) {

                            // 'Becomes' case.
                            case ':':
                                // If followed by '=', tokenize the symbol. Otherwise, invalid.
                                if (buffer[tracer+1] == '=') {
                                    lexemes[numtokens].symbol_id = becomessym;
                                    strcpy(lexemes[numtokens].name, ":=");
                                    numtokens++;
                                    tracer++;
                                }
                                else {
                                    errorcode[3] = true;
                                    return numtokens;
                                }
                                break;

                            // 'GEQ' case..
                            case '>':
                                // If followed by '=' or ' ', tokenize the symbol. Otherwise, invalid.
                                if (buffer[tracer+1] == '=') {
                                    lexemes[numtokens].symbol_id = geqsym;
                                    strcpy(lexemes[numtokens].name, ">=");
                                    numtokens++;
                                    tracer++;
                                }
                                else {
                                    lexemes[numtokens].symbol_id = gtrsym;
                                    tokenSym(lexemes, &numtokens, gtrsym, ">");
                                }
                                break;

                            // 'LEQ' case..
                            case '<':
                                // If followed by '=' or ' ', tokenize the symbol. Otherwise, invalid.
                                if (buffer[tracer+1] == '=') {
                                    lexemes[numtokens].symbol_id = leqsym;
                                    strcpy(lexemes[numtokens].name, "<=");
                                    numtokens++;
                                    tracer++;
                                }
                                else {
                                    lexemes[numtokens].symbol_id = lessym;
                                    tokenSym(lexemes, &numtokens, lessym, "<");
                                }
                                break;

                            // All other cases deal with single symbols.
                            case '+':
                                tokenSym(lexemes, &numtokens, plussym, "+");
                                break;

                            case '-':
                                tokenSym(lexemes, &numtokens, minussym, "-");
                                break;

                            case '*':
                                tokenSym(lexemes, &numtokens, multsym, "*");
                                break;

                            case '/':
                                tokenSym(lexemes, &numtokens, slashsym, "/");
                                break;

                            case '(':
                                tokenSym(lexemes, &numtokens, lparentsym, "(");
                                break;

                            case ')':
                                tokenSym(lexemes, &numtokens, rparentsym, ")");
                                break;

                            case '=':
                                tokenSym(lexemes, &numtokens, eqsym, "=");
                                break;

                            case ',':
                                tokenSym(lexemes, &numtokens, commasym, ",");
                                break;

                            case '.':
                                tokenSym(lexemes, &numtokens, periodsym, ".");
                                break;

                            case ';':
                                tokenSym(lexemes, &numtokens, semicolonsym, ";");
                                break;

                            // Default is blank.
                            default:
                                break;
                            }
                            tracer++;
                        }
                    }
                }

                // An invalid symbol should throw an error and stops execution immediately.
                if (errorflag) {
                    /* DEBUG. */
                    printf("\nTHIS F**KER -> %d AKA %c", tracer, buffer[tracer]);

                    errorcode[3] = true;
                    return numtokens;
                }
            }
        }
        else tracer++;
    }

    return numtokens;
}

void report(token* lexemes, int tokensFlag, int length) {
    // Local variables.
    int n;
    FILE* fptr;

    // Prepare output file.
    fptr = fopen("scanner.txt", "w");

    // Print lexeme list, first of all.
    fprintf(fptr, "\nLexeme Table:\n%10s %10s", "lexeme", "token type");
    if (tokensFlag) printf("\nLexeme Table:\n%10s %10s", "lexeme", "token type");

    // Print tokens. Handle the special cases for printing, like identifiers, on a case-by-case basis.
    for (n = 0; n < length; n++) {
        fprintf(fptr, "\n%10s %10d", lexemes[n].name, lexemes[n].symbol_id);
        if (tokensFlag) printf("\n%10s %10d", lexemes[n].name, lexemes[n].symbol_id);
    }
    fprintf(fptr, "\n\nLexeme List:\n");
    if (tokensFlag) printf("\n\nLexeme List:\n");

    // Now print tokens in stream form.
    for (n = 0; n < length; n++) {
        fprintf(fptr, "%d ", lexemes[n].symbol_id);
        if (tokensFlag) printf("%d ", lexemes[n].symbol_id);
        if (lexemes[n].symbol_id == identsym || lexemes[n].symbol_id == numbersym) fprintf(fptr, "%s ", lexemes[n].name);
        if ((tokensFlag) && (lexemes[n].symbol_id == identsym || lexemes[n].symbol_id == numbersym)) printf("%s ", lexemes[n].name);
    }
    puts("\n");
    fclose(fptr);

    return;
}

int invalid(char value) {

    // Identify invisible non-whitespace characters.
    if (value >= 0 && value <= 31) return 1;

    return 0;
}

int isLetter(char value) {

    // Identify whether the new value is an alphabetical letter.
    if ((value >= ASCII_A && value <= ASCII_Z) || (value >= ASCII_LA && value <= ASCII_LZ)) return 1;

    return 0;
}

int isDigit(char value) {

    // Identify whether the new value is a numerical digit.
    if (value >= ASCII_0 && value <= ASCII_9) return 1;

    return 0;
}

void tokenWord(token* lexemes, int* token_index, int word_id, char* buffer) {

    // Write the given word to the symbol table. If it is an identifier, take this procedure.
    if (word_id == -1) {
            lexemes[*token_index].symbol_id = identsym;
            strcpy(lexemes[*token_index].name, buffer);
            *token_index += 1;
    }
    // If a reserved word, take it and write it to the token buffer.
    else {

        // Identify the correct symbol.
        switch(word_id) {

        case 0:
            lexemes[*token_index].symbol_id = constsym;
            break;

        case 1:
            lexemes[*token_index].symbol_id = varsym;
            break;

        case 2:
            lexemes[*token_index].symbol_id = procsym;
            break;

        case 3:
            lexemes[*token_index].symbol_id = callsym;
            break;

        case 4:
            lexemes[*token_index].symbol_id = beginsym;
            break;

        case 5:
            lexemes[*token_index].symbol_id = endsym;
            break;

        case 6:
            lexemes[*token_index].symbol_id = ifsym;
            break;

        case 7:
            lexemes[*token_index].symbol_id = thensym;
            break;

        case 8:
            lexemes[*token_index].symbol_id = elsesym;
            break;

        case 9:
            lexemes[*token_index].symbol_id = whilesym;
            break;

        case 10:
            lexemes[*token_index].symbol_id = dosym;
            break;

        case 11:
            lexemes[*token_index].symbol_id = readsym;
            break;

        case 12:
            lexemes[*token_index].symbol_id = writesym;
            break;

        case 13:
            lexemes[*token_index].symbol_id = oddsym;
            break;

        case 14:
            lexemes[*token_index].symbol_id = varsym;
            break;

        default:
            break;
        }
        // Copy reserve word into 'name' field and increment table pointer.
        strcpy(lexemes[*token_index].name, words[word_id]);
        *token_index += 1;
    }

    return;
}

void tokenNum(token* lexemes, int* token_index, char* buffer, int length) {

    // Copy number.
    lexemes[*token_index].symbol_id = numbersym;
    strcpy(lexemes[*token_index].name, buffer);
    *token_index += 1;

    return;
}

void tokenSym(token* lexemes, int* token_index, int sym_id, const char* token_name) {

    // Copy symbol.
    lexemes[*token_index].symbol_id = sym_id;
    strcpy(lexemes[*token_index].name, token_name);
    *token_index += 1;

    return;
}
