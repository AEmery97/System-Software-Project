// COP 3402 - Systems Software
// 4-14-17 | Austin Peace & Andrew Emery

#ifndef COMPILER_H
#define COMPILER_H

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

#define MAX_SOURCE_FILE 5000
#define MAX_WORD_SIZE 11
#define MAX_SYMBOLS 100
#define MAX_NUM_SIZE 6
#define RESERVED_WORDS 15
#define RESERVED_SYMBOLS 13
#define ASCII_A 65
#define ASCII_Z 90
#define ASCII_LA 97
#define ASCII_LZ 122
#define ASCII_0 48
#define ASCII_9 57
#define MAX_TOKENS 500
#define MAX_CODE_SIZE 100
#define MAX_STACK_HEIGHT 5000
#define REGFILE_SIZE 16

typedef struct {

    int op;
    int r;
    int l;
    int m;

} instruction;

typedef struct {

    instruction IR;
    int SP;
    int BP;
    int PC;
    int* registerFile;

} machine;

typedef struct {

    int symbol;     // token_type;
	int kind; 		// const = 1, var = 2, proc = 3
	char name[MAX_WORD_SIZE];	// name up to 11 chars
	int val; 		// number (ASCII value)
	int level; 		// L level
	int addr; 		// M address

} symbol;

typedef struct {

    char name[MAX_WORD_SIZE];
    int symbol_id;

} token;

// MAIN EXECUTION STAGES.

int scanner(char* filename, int tokensFlag, int* errorFlag);
void parser(const char* filename, int token_index, int assemblyFlag, int* errorFlag);
int virtualMachine(const char* filename, int vmFlag);

// ENUMERATIONS.

enum bool {false, true};

enum ISA {lit=1, rtn, lod, sto, cal, inc, jmp, jpc, sio1, sio2, sio3,
neg, add, sub, mul, dvd, odd, mod, eql, neq, lss, leq, gtr, geq};

typedef enum {nulsym = 1, identsym, numbersym, plussym, minussym,
multsym,  slashsym, oddsym, eqsym, neqsym, lessym, leqsym,
gtrsym, geqsym, lparentsym, rparentsym, commasym, semicolonsym,
periodsym, becomessym, beginsym, endsym, ifsym, thensym,
whilesym, dosym, callsym, constsym, varsym, procsym, writesym,
readsym , elsesym } token_type;

typedef enum {blockf, statementf, conditionf, expressionf, termf, factorf} subtree;

#endif // COMPILER_H
