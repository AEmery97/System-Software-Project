// COP 3402 - Systems Software
// 4-14-17 | Austin Peace & Andrew Emery
// Programming Assignment 3 -- Parser/Generator

// HEADER.

#include "Compiler.h"

// PROTOTYPES.

int program(int* errorFlag);
int block(int* errorFlag);
int statement(int* errorFlag);
int condition(int* errorFlag);
int expression(int* errorFlag);
int term(int* errorFlag);
int factor(int* errorFlag);
int relation(int symbol);

void errorms(int code);
int locate(const char* symbol_name);
void emit(int op, int r, int l, int m);
int Recover(int expected, int subcall);
int usable(int current, int subcall);
void update();
void NextToken();

// GLOBALS.

token* tokens;
token current_token;
int thistoken;
int tlength;
instruction storage[MAX_CODE_SIZE];
symbol symtable[MAX_SYMBOLS];
int stacktop;
int code_index;
int lexlevel;
int regfile;

// ERROR RECOVERY.
const int blockfollow[] = {periodsym, semicolonsym};
const int statefollow[] = {periodsym, semicolonsym, endsym};
const int confollow[] = {thensym, dosym};
const int expfollow[] = {periodsym, semicolonsym, rparentsym, endsym, thensym, dosym};
const int termfollow[] = {periodsym, semicolonsym, rparentsym, plussym, minussym, endsym, thensym, dosym};
const int factfollow[] = {periodsym, semicolonsym, rparentsym, plussym, minussym, multsym, slashsym, endsym, thensym, dosym};

// MAIN PROGRAM.

void parser(const char* filename, int length, int aFlag, int* errorFlag) {
    // Initialize locals.
    tlength = length;
    stacktop = 0;
    lexlevel = -1;
    code_index = 0;
    thistoken = 0;
    regfile = 0;
    FILE* fp;

    // Get tokenized input from file.
    fp = fopen(filename, "r");
    if (fp == NULL) {
        printf("\nERROR: Unable to locate/open token file! Scanner output failure.\n");
        *errorFlag = true;
        return;
    }

    tokens = malloc(length*sizeof(token));
    int n;
    for (n = 0; n < tlength; n++) {
        fscanf(fp, "%d ", &tokens[n].symbol_id);
        if (tokens[n].symbol_id == identsym || tokens[n].symbol_id == numbersym) {
            fscanf(fp, "%s ", tokens[n].name);
        }
    }
    fclose(fp);

    // Begin parsing.
    if (!program(errorFlag)) {
        *errorFlag = true;
        return;
    }
    else {
        // Intermediate PARSER report.
        printf("\nPARSING COMPLETE. PROGRAM IS SYNTACTICALLY CORRECT. EXECUTING P-MACHINE...\n");
    }

    // Export generated assembly to file.
    fp = fopen("assembly.txt", "w");
    if (fp == NULL) {
        printf("\nERROR: Unable to create assembly file.\n");
        *errorFlag = true;
        return;
    }

    if (aFlag) printf("\nAssembly Generated:\n");

    for (n = 0; n < code_index; n++) {
        fprintf(fp, "%d %d %d %d\n", storage[n].op, storage[n].r, storage[n].l, storage[n].m);
        if (aFlag) printf("%d %d %d %d\n", storage[n].op, storage[n].r, storage[n].l, storage[n].m);
    }
    fclose(fp);

    // Tidy up heap memory.
    free(tokens);

    return;
}

int program(int* errorFlag) {

    // 'BLOCK' expects 'const', 'var', or 'procedure'.
    NextToken();

    // 'BLOCK' call.
    if (!block(errorFlag)) {
        *errorFlag = true;
    }

    // Expected next token is '.'.
    if (current_token.symbol_id != periodsym) {
        errorms(9);
        *errorFlag = true;
    }

    if (*errorFlag) return 0;
    return 1;
}

int block(int* errorFlag) {
    // Local Generation tools.
    int sym_index = stacktop;
    int procbody = 4;
    int jump = code_index;

    // Update lexicographical level.
    lexlevel++;
    // Generate jump instruction.
    emit(jmp, 0, 0, 0);

    // 'CONST' declaration branch.
    if (current_token.symbol_id == constsym) {

        do {

            // Expects 'ident'.
            NextToken();

            if (current_token.symbol_id != identsym) {
                errorms(4);
                *errorFlag = true;
                printf("\nERROR SOURCE: %d\nTOKEN #: %d\n\n", current_token.symbol_id, thistoken);
                int rec;
                rec = Recover(current_token.symbol_id, blockf);
                if (rec == 0) return 1;
                else if (rec == -1) return 0;
            }

            // Copy identifier to symbol table.
            symtable[sym_index].kind = 1;
            strcpy(symtable[sym_index].name, current_token.name);

            // Expects '='.
            NextToken();

            if (current_token.symbol_id != eqsym) {
                errorms(3);
                *errorFlag = true;
                if (current_token.symbol_id == becomessym) errorms(1);
                printf("\nERROR SOURCE: %d\nTOKEN #: %d\n\n", current_token.symbol_id, thistoken);
                int rec;
                rec = Recover(current_token.symbol_id, blockf);
                if (rec == 0) return 1;
                else if (rec == -1) return 0;
            }

            // Expects 'number'.
            else NextToken();

            if (current_token.symbol_id != numbersym) {
                errorms(2);
                *errorFlag = true;
                printf("\nERROR SOURCE: %d\nTOKEN #: %d\n\n", current_token.symbol_id, thistoken);
                int rec;
                rec = Recover(current_token.symbol_id, blockf);
                if (rec == 0) return 1;
                else if (rec == -1) return 0;
            }

            // Copy value to symbol table.
            symtable[sym_index].val = atoi(current_token.name);
            sym_index++, stacktop++;

            // Expects ',' or ';'.
            NextToken();

        } while (current_token.symbol_id == commasym);

        // The declaration chain must end in a semicolon.
        if (current_token.symbol_id != semicolonsym) {
            errorms(17);
            printf("\nERROR SOURCE: %d\nTOKEN #: %d\n\n", current_token.symbol_id, thistoken);
            int rec;
            rec = Recover(current_token.symbol_id, blockf);
            if (rec == 0) return 1;
            else if (rec == -1) return 0;
        }

        // 'STATEMENT' expects 'ident', 'call', 'begin', 'if' or 'while'.
        else NextToken();
    }

    // 'VAR' branch.
    else if (current_token.symbol_id == varsym) {

        do {

            // Expects 'ident'.
            NextToken();

            if (current_token.symbol_id != identsym) {
                errorms(4);
                *errorFlag = true;
                printf("\nERROR SOURCE: %d\nTOKEN #: %d\n\n", current_token.symbol_id, thistoken);
                int rec;
                rec = Recover(current_token.symbol_id, blockf);
                if (rec == 0) return 1;
                else if (rec == -1) return 0;
            }

            // Copy identifier to symbol table.
            symtable[sym_index].kind = 2;
            strcpy(symtable[sym_index].name, current_token.name);
            symtable[sym_index].level = lexlevel;
            symtable[sym_index].addr = procbody++;
            sym_index++, stacktop++;

            // Expects ',' or ';'.
            NextToken();

        } while (current_token.symbol_id == commasym);

        // The declaration chain must end in a semicolon.
        if (current_token.symbol_id != semicolonsym) {
            errorms(17);
            printf("\nERROR SOURCE: %d\nTOKEN #: %d\n\n", current_token.symbol_id, thistoken);
            int rec;
            rec = Recover(current_token.symbol_id, blockf);
            if (rec == 0) return 1;
            else if (rec == -1) return 0;
        }

        // 'STATEMENT' expects 'ident', 'call', 'begin', 'if' or 'while'.
        else NextToken();
    }

    // 'PROCEDURE' branch.
    while (current_token.symbol_id == procsym) {

        // Expects 'ident'.
        NextToken();

        if (current_token.symbol_id != identsym) {
            errorms(4);
            *errorFlag = true;
            printf("\nERROR SOURCE: %d\nTOKEN #: %d\n\n", current_token.symbol_id, thistoken);
            int rec;
            rec = Recover(current_token.symbol_id, blockf);
            if (rec == 0) return 1;
            else if (rec == -1) return 0;
        }

        // Copy identifier to symbol table.
        symtable[sym_index].kind = 3;
        strcpy(symtable[sym_index].name, current_token.name);
        symtable[sym_index].level = lexlevel;
        symtable[sym_index].addr = code_index+1;
        sym_index++;
        stacktop++;

        // Expects ';' and 'BLOCK' call.
        NextToken();

        if (current_token.symbol_id != semicolonsym) {
            errorms(6);
            puts("\n");
            errorms(17);
            *errorFlag = true;
            printf("\nERROR SOURCE: %d\nTOKEN #: %d\n\n", current_token.symbol_id, thistoken);
            int rec;
            rec = Recover(current_token.symbol_id, blockf);
            if (rec == 0) return 1;
            else if (rec == -1) return 0;
        }

        else NextToken();

        if (!block(errorFlag)) {
            *errorFlag = true;
            Recover(0, blockf);
            return 1;
        }

        // The declaration chain must end in a semicolon.
        if (current_token.symbol_id != semicolonsym) {
            errorms(17);
            *errorFlag = true;
            printf("\nERROR SOURCE: %d\nTOKEN #: %d\n\n", current_token.symbol_id, thistoken);
            int rec;
            rec = Recover(current_token.symbol_id, blockf);
            if (rec == 0) return 1;
            else if (rec == -1) return 0;
        }

        // 'STATEMENT' expects 'ident', 'call', 'begin', 'if' or 'while'.
        else NextToken();
    }

    // Update jump instruction.
    storage[jump].m = code_index;
    emit(inc, 0, 0, procbody);

    // 'STATEMENT' branch.
    if (!statement(errorFlag)) {
        errorms(7);
        *errorFlag = true;
        printf("\nERROR SOURCE: %d\nTOKEN #: %d\n\n", current_token.symbol_id, thistoken);
        int rec;
        rec = Recover(current_token.symbol_id, blockf);
        if (rec == 0) return 1;
        else if (rec == -1) return 0;
    }

    // Generate return instruction.
    emit(rtn, 0, 0, 0);

    // Decrement lexicographical level. Remove all current-level symbols for cleanliness.
    update();
    lexlevel--;

    if (*errorFlag) return 0;
    return 1;
}

int statement(int* errorFlag) {
    // Local Generation tools.
    int sym_index;
    int iftemp = 0, elsetemp = 0, cx1 = 0, cx2 = 0;

    // 'IDENT' branch.
    if (current_token.symbol_id == identsym) {

        // Identifier must be previously declared and of valid type.
        sym_index = locate(current_token.name);
        if (sym_index == -1) {
            errorms(11);
            *errorFlag = true;
            printf("\nERROR SOURCE: %d\nTOKEN #: %d\n\n", current_token.symbol_id, thistoken);
            int rec;
            rec = Recover(current_token.symbol_id, blockf);
            if (rec == 0) return 1;
            else if (rec == -1) return 0;
        }
        if (symtable[sym_index].kind != 2) {
            errorms(12);
            *errorFlag = true;
            printf("\nERROR SOURCE: %d\nTOKEN #: %d\n\n", current_token.symbol_id, thistoken);
            int rec;
            rec = Recover(current_token.symbol_id, blockf);
            if (rec == 0) return 1;
            else if (rec == -1) return 0;
        }

        // Expects 'becomes'.
        NextToken();

        if (current_token.symbol_id != becomessym) {
            errorms(13);
            *errorFlag = true;
            printf("\nERROR SOURCE: %d\nTOKEN #: %d\n\n", current_token.symbol_id, thistoken);
            int rec;
            rec = Recover(current_token.symbol_id, blockf);
            if (rec == 0) return 1;
            else if (rec == -1) return 0;
        }

        // 'EXPRESSION' expects '+' or '-'.
        else NextToken();

        // 'EXPRESSION' call.
        if (!expression(errorFlag)) {
            *errorFlag = true;
            Recover(0, statementf);
            return 1;
        }
        emit(sto, regfile-1, (lexlevel - symtable[sym_index].level), symtable[sym_index].addr);
        regfile--;
    }

    // 'CALL' branch.
    else if (current_token.symbol_id == callsym) {

        // Expects 'ident'.
        NextToken();

        if (current_token.symbol_id != identsym) {
            errorms(14);
            *errorFlag = true;
            printf("\nERROR SOURCE: %d\nTOKEN #: %d\n\n", current_token.symbol_id, thistoken);
            int rec;
            rec = Recover(current_token.symbol_id, blockf);
            if (rec == 0) return 1;
            else if (rec == -1) return 0;
        }
        // Identifier must be previously declared and of valid type.
        sym_index = locate(current_token.name);
        if (sym_index == -1) {
            errorms(11);
            *errorFlag = true;
            printf("\nERROR SOURCE: %d\nTOKEN #: %d\n\n", current_token.symbol_id, thistoken);
            int rec;
            rec = Recover(current_token.symbol_id, blockf);
            if (rec == 0) return 1;
            else if (rec == -1) return 0;
        }
        if (symtable[sym_index].kind != 3) {
            errorms(14);
            puts("\n");
            errorms(15);
            printf("\nERROR SOURCE: %d\nTOKEN #: %d\n\n", current_token.symbol_id, thistoken);
            int rec;
            rec = Recover(current_token.symbol_id, blockf);
            if (rec == 0) return 1;
            else if (rec == -1) return 0;
        }
        // Generate instruction.
        emit(cal, 0, (lexlevel - symtable[sym_index].level), symtable[sym_index].addr);

        NextToken();
    }

    // 'BEGIN' branch.
    else if (current_token.symbol_id == beginsym) {

        // 'STATEMENT' expects 'ident', 'call', 'begin', 'if' or 'while'.
        NextToken();

        // 'STATEMENT' call. Expects ';'.
        if (!statement(errorFlag)) {
            errorms(7);
            *errorFlag = true;
            printf("\nERROR SOURCE: %d\nTOKEN #: %d\n\n", current_token.symbol_id, thistoken);
            int rec;
            rec = Recover(current_token.symbol_id, blockf);
            if (rec == 0) return 1;
            else if (rec == -1) return 0;
        }

        while (current_token.symbol_id == semicolonsym) {

            // 'STATEMENT' expects 'ident', 'call', 'begin', 'if' or 'while'.
            NextToken();

            // 'STATEMENT' call. Expects ';'.
            if (!statement(errorFlag)) {
                errorms(7);
                *errorFlag = true;
                printf("\nERROR SOURCE: %d\nTOKEN #: %d\n\n", current_token.symbol_id, thistoken);
                int rec;
                rec = Recover(current_token.symbol_id, blockf);
                if (rec == 0) return 1;
                else if (rec == -1) return 0;
            }
        }

        // Expects 'end'.
        if (current_token.symbol_id != endsym) {
            errorms(26);
            *errorFlag = true;
            printf("\nERROR SOURCE: %d\nTOKEN #: %d\n\n", current_token.symbol_id, thistoken);
            int rec;
            rec = Recover(current_token.symbol_id, blockf);
            if (rec == 0) return 1;
            else if (rec == -1) return 0;
        }

        // Expects ';'.
        else NextToken();
    }

    // 'IF' branch.
    else if (current_token.symbol_id == ifsym) {

        // 'CONDITION' expects 'odd' or identifier.
        NextToken();

        // 'CONDITION' call.
        if (!condition(errorFlag)) {
            *errorFlag = true;
            Recover(0, conditionf);
            return 1;
        }

        // Expects 'then';
        if (current_token.symbol_id != thensym) {
            errorms(16);
            *errorFlag = true;
            printf("\nERROR SOURCE: %d\nTOKEN #: %d\n\n", current_token.symbol_id, thistoken);
            int rec;
            rec = Recover(current_token.symbol_id, blockf);
            if (rec == 0) return 1;
            else if (rec == -1) return 0;
        }

        // 'STATEMENT' expects 'ident', 'call', 'begin', 'if' or 'while'.
        else NextToken();

        // Store current index and generate instruction.
        iftemp = code_index;
        emit(jpc, regfile-1, 0, 0);
        regfile--;

        // 'STATEMENT' call.
        if (!statement(errorFlag)) {
            *errorFlag = true;
            Recover(0, statementf);
            return 1;
        }
        // Now update jump location in assembly.
        storage[iftemp].m = code_index;

        // Check for existence of optional 'ELSE'.
        if (current_token.symbol_id == elsesym) {

            // 'STATEMENT' expects 'ident', 'call', 'begin', 'if' or 'while'.
            NextToken();

            // This next jump must execute opposite the other.
            emit(lit, 1, 0, 0);
            emit(eql, 0, 0, 1);
            // Get code index.
            elsetemp = code_index;
            // Generate instruction.
            emit(jpc, 0, 0, 0);

            // 'STATEMENT' call.
            if (!statement(errorFlag)) {
                *errorFlag = true;
                Recover(0, statementf);
                return 1;
            }
            // Now update the 'else' jump location.
            storage[elsetemp].m = code_index;
        }
    }

    // 'WHILE' branch.
    else if (current_token.symbol_id == whilesym) {
        // Save current index.
        cx1 = code_index;
        // 'CONDITION' expects 'odd' or identifier.
        NextToken();

        // 'CONDITION' call. Expects 'do' to follow.
        if (!condition(errorFlag)) {
            *errorFlag = true;
            Recover(0, conditionf);
            return 1;
        }
        // Save new index.
        cx2 = code_index;
        // Generate instruction.
        emit(jpc, 0, 0, 0);

        // Expects 'do'.
        if (current_token.symbol_id != dosym) {
            errorms(18);
            *errorFlag = true;
            printf("\nERROR SOURCE: %d\nTOKEN #: %d\n\n", current_token.symbol_id, thistoken);
            int rec;
            rec = Recover(current_token.symbol_id, blockf);
            if (rec == 0) return 1;
            else if (rec == -1) return 0;
        }

        // 'STATEMENT' expects 'ident', 'call', 'begin', 'if' or 'while'.
        else NextToken();

        // 'STATEMENT' call.
        if (!statement(errorFlag)) {
            *errorFlag = true;
            Recover(0, statementf);
            return 1;
        }
        // Generate instruction and update previous.
        emit(jmp, 0, 0, cx1);
        storage[cx2].m = code_index;
    }

    if (*errorFlag) return 0;
    return 1;
}

int condition(int* errorFlag) {
    // Local Generation tools.
    int opr;
    if (current_token.symbol_id == oddsym) {

        // Expects '+','-' or identifier first.
        NextToken();

        // 'EXPRESSION' call.
        if (!expression(errorFlag)) {
            *errorFlag = true;
            Recover(0, expressionf);
            return 1;
        }
        emit(odd, regfile-1, 0, 0);
        regfile--;
    }

    else {

        // 'EXPRESSION' call w/o next token.
        if (!expression(errorFlag)) {
            *errorFlag = true;
            Recover(0, expressionf);
            return 1;
        }

        // Expects relational operator followed by 'EXPRESSION' call.
        if (!relation(current_token.symbol_id)) {
            errorms(20);
            *errorFlag = true;
            printf("\nERROR SOURCE: %d\nTOKEN #: %d\n\n", current_token.symbol_id, thistoken);
        }
        // Determine operator.
        switch(current_token.symbol_id) {

            case eqsym:
                opr = eql;
                break;

            case neqsym:
                opr = neq;
                break;

            case lessym:
                opr = lss;
                break;

            case leqsym:
                opr = leq;
                break;

            case gtrsym:
                opr = gtr;
                break;

            case geqsym:
                opr = geq;
                break;
        }

        // 'EXPRESSION' expects '+' or '-'.
        NextToken();

        // 'EXPRESSION' call.
        if (!expression(errorFlag)) {
            *errorFlag = true;
            Recover(0, expressionf);
            return 1;
        }
        emit(opr, regfile-2, regfile-2, regfile-1);
        regfile--;
    }

    if (*errorFlag) return 0;
    return 1;
}

int expression(int* errorFlag) {
    // Local Generation tools.
    int addopr;

    if (current_token.symbol_id == plussym || current_token.symbol_id == minussym) {
        // Designate operation.
        addopr = current_token.symbol_id;

        // Next token and 'TERM' call.
        NextToken();
        if (!term(errorFlag)) {
            *errorFlag = true;
            Recover(0, termf);
            return 1;
        }
        // Negation.
        if (addopr == minussym) {
            emit(neg, regfile-1, regfile-1, 0);
            regfile--;
        }

    }

    // Ordinary 'TERM' call.
    else {
        if (!term(errorFlag)) {
            *errorFlag = true;
            Recover(0, termf);
            return 1;
        }
    }

    // 'EXPRESSION' loop.
    while (current_token.symbol_id == plussym || current_token.symbol_id == minussym) {
        // Designate operation.
        addopr = current_token.symbol_id;

        // Expects '+' or '-' to sustain term loop.
        NextToken();

        // 'TERM' call, followed by another symbol ('+', '-', or other.)
        if (!term(errorFlag)) {
            *errorFlag = true;
            Recover(0, termf);
            return 1;
        }
        // Addition.
        if (addopr == plussym) {
            emit(add, regfile-2, regfile-2, regfile-1);
            regfile--;
        }
        // Subtraction.
        else {
            emit(sub, regfile-2, regfile-2, regfile-1);
            regfile--;
        }
    }

    if (*errorFlag) return 0;
    return 1;
}

int term(int* errorFlag) {
    // Local Generation tools.
    int mulopr;

    // 'FACTOR' call.
    if (!factor(errorFlag)) {
        *errorFlag = true;
        Recover(0, factorf);
        return 1;
    }

    while (current_token.symbol_id == multsym || current_token.symbol_id == slashsym) {
        // Designate operation.
        mulopr = current_token.symbol_id;

        // Get next token for 'FACTOR' call.
        NextToken();

        // 'FACTOR' call.
        if (!factor(errorFlag)) {
            *errorFlag = true;
            Recover(0, factorf);
            return 1;
        }
        // Multiplication.
        if (mulopr == multsym) {
            emit(mul, regfile-2, regfile-2, regfile-1);
            regfile--;
        }
        // Division.
        else {
            emit(dvd, regfile-2, regfile-2, regfile-1);
            regfile--;
        }
    }

    if (*errorFlag) return 0;
    return 1;
}

int factor(int* errorFlag) {
    // Local Generation tools.
    int sym_index;

    // Expects 'ident'...
    if (current_token.symbol_id == identsym) {

        // Identifier must be previously declared and of valid type.
        sym_index = locate(current_token.name);
        if (sym_index == -1) {
            errorms(11);
            *errorFlag = true;
            printf("\nERROR SOURCE: %d\nTOKEN #: %d\n\n", current_token.symbol_id, thistoken);
            return 1;
        }
        // Variables invoke 'LOD'.
        if (symtable[sym_index].kind == 2) {
            emit(lod, regfile++, (lexlevel - symtable[sym_index].level), symtable[sym_index].addr);
        }
        // Constants invoke 'LIT'.
        else if (symtable[sym_index].kind == 1) {
            emit(lit, regfile++, 0, symtable[sym_index].val);
        }
        else {
            errorms(21);
            printf("\nERROR SOURCE: %d\nTOKEN #: %d\n\n", current_token.symbol_id, thistoken);
        }

        NextToken();
    }
    // ...or 'number'...
    else if (current_token.symbol_id == numbersym) {

        // Numbers are treated with 'LIT' as well.
        emit(lit, regfile++, 0, atoi(current_token.name));

        NextToken();
    }
    // ...or maybe the '('.
    else if (current_token.symbol_id == lparentsym) {

        // 'EXPRESSION' expects '+' or '-'.
        NextToken();

        // 'EXPRESSION' call.
        if (!expression(errorFlag)) {
            *errorFlag = true;
            Recover(0, expressionf);
            return 1;
        }

        // Must close with ')'.
        if (current_token.symbol_id != rparentsym) {
            errorms(22);
            *errorFlag = true;
            printf("\nERROR SOURCE: %d\nTOKEN #: %d\n\n", current_token.symbol_id, thistoken);
            int rec;
            rec = Recover(current_token.symbol_id, factorf);
            if (rec == 0) return 1;
            else if (rec == -1) return 0;
        }
        else NextToken();
    }

    // Undiagnosed issues funnel here.
    else {
        errorms(23);
        printf("\nERROR SOURCE: %d\nTOKEN #: %d\n\n", current_token.symbol_id, thistoken);
        return 0;
    }

    if (*errorFlag) return 0;
    return 1;
}

int relation(int symbol) {

    // Return whether a valid relation.
    int relations[] = {eqsym, neqsym, lessym, leqsym, gtrsym, geqsym};
    int n;

    for (n = 0; n < 6; n++) {
        if (symbol == relations[n]) return true;
    }

    return false;
}

void errorms(int code) {
	printf("ERROR: ");
	switch(code) {

		case 1:
			printf("Use = instead of :=. (code: %d)", code);
			break;

		case 2:
			printf("= must be followed by a number.(code: %d)", code);
			break;

		case 3:
			printf("Identifier must be followed by =. (code: %d)", code);
			break;

		case 4:
			printf("const, var, or procedure must be followed by identifier. (code: %d)", code);
			break;

		case 5:
			printf("Semicolon or comma missing. (code: %d)", code);
			break;

		case 6:
			printf("Incorrect symbol after procedure declaration. (code: %d)", code);
			break;

		case 7:
			printf("Invalid statement.(code: %d)", code);
			break;

		case 8:
			printf("Incorrect symbol after statement part in block. (code: %d)", code);
			break;

		case 9:
			printf("Period expected. (code: %d)", code);
			return;
			break;

		case 10:
			printf("Semicolon between statements missing. (code: %d)", code);
			break;

		case 11:
			printf("Undeclared identifier. (code: %d)", code);
			break;

		case 12:
			printf("Assignment to constant or procedure is not allowed. (code: %d)", code);
			break;

		case 13:
			printf("Assignment operator expected. (code: %d)", code);
			break;

		case 14:
			printf("'Call' must be followed by a procedure. (code: %d)", code);
			break;

		case 15:
			printf("Call of a constant or variable is meaningless. (code: %d)", code);
			break;

		case 16:
			printf("'Then' expected.(code: %d)", code);
			break;

		case 17:
			printf("';' expected. (code: %d)", code);
			break;

		case 18:
			printf("'Do' expected. (code: %d)", code);
			break;

		case 19:
			printf("Incorrect symbol following statement. (code: %d)", code);
			break;

		case 20:
			printf("Relational operator expected. (code: %d)", code);
			break;

		case 21:
			printf("Expression must not contain a procedure identifier. (code: %d)", code);
			break;

		case 22:
			printf("Right parenthesis missing. (code: %d)", code);
			break;

		case 23:
			printf("Invalid factor. (code: %d)", code);
			break;

		case 24:
			printf("An expression cannot begin with this symbol. (code: %d)", code);
			break;

		case 25:
			printf("This number is too large. (code: %d)", code);
			break;

        case 26:
            printf("'end' keyword expected. (code: %d)", code);
            break;

		default:
			printf("Unrecognized Error (code: %d)", code);
	}
}

int locate(const char* symbol_name) {

    int n;
    for (n = stacktop; n >= 0; n--) {
        if (!strcmp(symbol_name, symtable[n].name) && (symtable[n].level <= lexlevel)) {
            // Match found. Return index.
            return n;
        }
    }

    return -1;
}

void emit(int op, int r, int l, int m) {

	if(code_index > MAX_CODE_SIZE) {
		errorms(25);
	}

	else {
		storage[code_index].op = op;
		storage[code_index].r = r;
		storage[code_index].l = l;
		storage[code_index].m = m;
		code_index++;
	}
}

int Recover(int expected, int subcall) {

    // If the next token isn't what we need (nor can we continue the parse) move to next token.
    while ((tokens[thistoken+1].symbol_id != expected) && (usable(tokens[thistoken+1].symbol_id, subcall) == -1)) {
        // If we run out of new tokens to have, just stop parsing.
        if (thistoken >= tlength) return 0;

        NextToken();
    }
    if (usable(tokens[thistoken].symbol_id, subcall) != -1) return 0;
    else return 1;
}

int usable(int current, int subcall) {

    int n;

    // The subcall we are in can return a valid symbol
    switch (subcall) {

        case blockf:
            for (n = 0; n < 2; n++) {
                if (current == blockfollow[n]) {
                    return n;
                }
            }
            break;

        case statementf:
            for (n = 0; n < 3; n++) {
                if (current == statefollow[n]) {
                    return n;
                }
            }
            break;

        case conditionf:
            for (n = 0; n < 2; n++) {
                if (current == confollow[n]) {
                    return n;
                }
            }
            break;

        case expressionf:
            for (n = 0; n < 6; n++) {
                if (current == expfollow[n]) {
                    return n;
                }
            }
            break;

        case termf:
            for (n = 0; n < 8; n++) {
                if (current == termfollow[n]) {
                    return n;
                }
            }
            break;

        case factorf:
            for (n = 0; n < 10; n++) {
                if (current == factfollow[n]) {
                    return n;
                }
            }
            break;

        default:
            break;

    }
    return -1;
}

void update() {
    // Local variables.
    int n;

    for (n = stacktop; n >= 0; n--) {
        if (symtable[n].level > lexlevel) stacktop--;
    }

    return;
}

void NextToken() {

    // Get the next token from the token list.
    current_token.symbol_id = tokens[thistoken].symbol_id;
    strcpy(current_token.name, tokens[thistoken].name);
    thistoken++;

    return;
}
