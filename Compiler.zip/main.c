// COP 3402 - Systems Software
// 4-14-17 | Austin Peace & Andrew Emery
// Programming Assignment 4 -- Compiler

// HEADER.

#include "Compiler.h"

// MAIN PROGRAM.

int main(int argc, char* argv[]) {

    // Main variables.
    int tFlag = 0;
	int aFlag = 0;
	int VMFlag = 0;
	char* sourceFile;
	int length;
	int tokensLength;
	int errorFlag = 0;
	int i;

    // Check arguments for flags (and filename).
    for(i = 1; i < argc; i++) {

		if (strcmp(argv[i], "-l") == 0) {
			tFlag = 1;
		}
		else if (strcmp(argv[i],"-a") == 0) {
			aFlag = 1;
		}
		else if (strcmp(argv[i],"-v") == 0) {
			VMFlag = 1;
		}
		else {
			length = strlen(argv[i]) + 1;
			sourceFile = malloc(sizeof(char)* length);
			strcpy(sourceFile, argv[i]);
		}
	}

	// Run SCANNER.
    tokensLength = scanner(sourceFile, tFlag, &errorFlag);

    // Run PARSER.
    if (!errorFlag) {
        parser("tokens.txt", tokensLength, aFlag, &errorFlag);
    }
    else {
        printf("\nERROR: Scanning source file failed.");
    }

    // Run P-MACHINE with generated assembly code.
    if (!errorFlag) {
        virtualMachine("assembly.txt", VMFlag);
    }
    else {
        printf("\nPARSER DETECTED ERRORS. COMPILING HAS BEEN ABORTED.\n");
    }

	// Close output file.
	putchar('\n');

    return 0;
}
