INSTRUCTIONS TO COMPILE:

1. Open command line of choice (on Eustis, ensure the following files are all in the same, local directory):

- main.c
- pmachine.c
- scanner.c
- parser.c
- Compiler.h

2. Use command "gcc main.c pmachine.c scanner.c parser.c -o compiler" (no quotes) to produce the program "compiler". 
3. Run the compiler with the command "./compiler <arguments>" (no quotes). Acceptable arguments (max all 4):

"-l": Print scanner lexeme output (lexeme list and tokenization) to terminal.
"-a": Print generated assembly language (instructions) to terminal.
"-v": Print virtual machine execution of machine code to terminal.
<filename>: Must end in ".txt".

NOTES:
* Program is NOT designed to implement "int", "read" or "write" PL/0 language syntax (never specified in parser rubric. May run unpredictably).
* Program has been rigorously tested against simple, complex, multi-procedural, and various types of PL/0 source files. 
* In all tested cases, the final product resulted in either correct execution of assembly from syntactically correct source files or multiple error messages describing issues inherent in input.
* The folder "TESTS" contains all the source files the program was tested against, including the source file below and consequent output (found in "testout.txt").
* When not prompted to output results to the terminal, the program still reports results from the most recently run test case in these text files:
* Comments must be written inside /* */ in source code. 

- scanner.txt (scanner subprogram output)
- assembly.txt (parser/generator subprogram output)
- machine.txt (VM subprogram output)

*** ENSURE THE TEST FILE IS IN THE SAME DIRECTORY AS THE COMPILER EXECUTABLE. ***

SAMPLE PROGRAM:

>./compiler hardmode.txt -l -a -v > testout.txt

Source Program:
var x,y,z,v,w;
procedure a;
  var x,y,u,v;
  procedure b;
    var y,z,v;
    procedure c;
      var y,z;
      begin
        z:=1;
        x:=y+z+w;
      end;
    begin
      y:=x+u+w;
      call c;
    end;
  begin
    z:=2;
    u:=z+w;
    call b;
  end;
begin
  x:=1; y:=2; z:=3; v:=4; w:=5;
  x:=v+w;
  call a;
end.


Lexeme Table:
    lexeme token type
       var         29
         x          2
         ,         17
         y          2
         ,         17
         z          2
         ,         17
         v          2
         ,         17
         w          2
         ;         18
 procedure         30
         a          2
         ;         18
       var         29
         x          2
         ,         17
         y          2
         ,         17
         u          2
         ,         17
         v          2
         ;         18
 procedure         30
         b          2
         ;         18
       var         29
         y          2
         ,         17
         z          2
         ,         17
         v          2
         ;         18
 procedure         30
         c          2
         ;         18
       var         29
         y          2
         ,         17
         z          2
         ;         18
     begin         21
         z          2
        :=         20
         1          3
         ;         18
         x          2
        :=         20
         y          2
         +          4
         z          2
         +          4
         w          2
         ;         18
       end         22
         ;         18
     begin         21
         y          2
        :=         20
         x          2
         +          4
         u          2
         +          4
         w          2
         ;         18
      call         27
         c          2
         ;         18
       end         22
         ;         18
     begin         21
         z          2
        :=         20
         2          3
         ;         18
         u          2
        :=         20
         z          2
         +          4
         w          2
         ;         18
      call         27
         b          2
         ;         18
       end         22
         ;         18
     begin         21
         x          2
        :=         20
         1          3
         ;         18
         y          2
        :=         20
         2          3
         ;         18
         z          2
        :=         20
         3          3
         ;         18
         v          2
        :=         20
         4          3
         ;         18
         w          2
        :=         20
         5          3
         ;         18
         x          2
        :=         20
         v          2
         +          4
         w          2
         ;         18
      call         27
         a          2
         ;         18
       end         22
         .         19

Lexeme List:
29 2 x 17 2 y 17 2 z 17 2 v 17 2 w 18 30 2 a 18 29 2 x 17 2 y 17 2 u 17 2 v 18 30 2 b 18 29 2 y 17 2 z 17 2 v 18 30 2 c 18 29 2 y 17 2 z 18 21 2 z 20 3 1 18 2 x 20 2 y 4 2 z 4 2 w 18 22 18 21 2 y 20 2 x 4 2 u 4 2 w 18 27 2 c 18 22 18 21 2 z 20 3 2 18 2 u 20 2 z 4 2 w 18 27 2 b 18 22 18 21 2 x 20 3 1 18 2 y 20 3 2 18 2 z 20 3 3 18 2 v 20 3 4 18 2 w 20 3 5 18 2 x 20 2 v 4 2 w 18 27 2 a 18 22 19 


PARSING COMPLETE. PROGRAM IS SYNTACTICALLY CORRECT. EXECUTING P-MACHINE...

Assembly Generated:
7 0 0 32
7 0 0 23
7 0 0 14
7 0 0 4
6 0 0 6
1 0 0 1
4 0 0 5
3 0 0 4
3 1 0 5
13 0 0 1
3 1 3 8
13 0 0 1
4 0 2 4
2 0 0 0
6 0 0 7
3 0 1 4
3 1 1 6
13 0 0 1
3 1 2 8
13 0 0 1
4 0 0 4
5 0 0 4
2 0 0 0
6 0 0 8
1 0 0 2
4 0 1 6
3 0 1 6
3 1 1 8
13 0 0 1
4 0 0 6
5 0 0 3
2 0 0 0
6 0 0 9
1 0 0 1
4 0 0 4
1 0 0 2
4 0 0 5
1 0 0 3
4 0 0 6
1 0 0 4
4 0 0 7
1 0 0 5
4 0 0 8
3 0 0 7
3 1 0 8
13 0 0 1
4 0 0 4
5 0 0 2
2 0 0 0


LINE       OP        R        L        M
   0      jmp        0        0       32
   1      jmp        0        0       23
   2      jmp        0        0       14
   3      jmp        0        0        4
   4      inc        0        0        6
   5      lit        0        0        1
   6      sto        0        0        5
   7      lod        0        0        4
   8      lod        1        0        5
   9      add        0        0        1
  10      lod        1        3        8
  11      add        0        0        1
  12      sto        0        2        4
  13      rtn        0        0        0
  14      inc        0        0        7
  15      lod        0        1        4
  16      lod        1        1        6
  17      add        0        0        1
  18      lod        1        2        8
  19      add        0        0        1
  20      sto        0        0        4
  21      cal        0        0        4
  22      rtn        0        0        0
  23      inc        0        0        8
  24      lit        0        0        2
  25      sto        0        1        6
  26      lod        0        1        6
  27      lod        1        1        8
  28      add        0        0        1
  29      sto        0        0        6
  30      cal        0        0        3
  31      rtn        0        0        0
  32      inc        0        0        9
  33      lit        0        0        1
  34      sto        0        0        4
  35      lit        0        0        2
  36      sto        0        0        5
  37      lit        0        0        3
  38      sto        0        0        6
  39      lit        0        0        4
  40      sto        0        0        7
  41      lit        0        0        5
  42      sto        0        0        8
  43      lod        0        0        7
  44      lod        1        0        8
  45      add        0        0        1
  46      sto        0        0        4
  47      cal        0        0        2
  48      rtn        0        0        0


Initial Values                       pc     bp     sp
  0    jmp      0      0     32     32      1      0
 32    inc      0      0      9     33      1      9      0      0      0      0      0      0      0      0      0
 33    lit      0      0      1     34      1      9      0      0      0      0      0      0      0      0      0
 34    sto      0      0      4     35      1      9      0      0      0      0      1      0      0      0      0
 35    lit      0      0      2     36      1      9      0      0      0      0      1      0      0      0      0
 36    sto      0      0      5     37      1      9      0      0      0      0      1      2      0      0      0
 37    lit      0      0      3     38      1      9      0      0      0      0      1      2      0      0      0
 38    sto      0      0      6     39      1      9      0      0      0      0      1      2      3      0      0
 39    lit      0      0      4     40      1      9      0      0      0      0      1      2      3      0      0
 40    sto      0      0      7     41      1      9      0      0      0      0      1      2      3      4      0
 41    lit      0      0      5     42      1      9      0      0      0      0      1      2      3      4      0
 42    sto      0      0      8     43      1      9      0      0      0      0      1      2      3      4      5
 43    lod      0      0      7     44      1      9      0      0      0      0      1      2      3      4      5
 44    lod      1      0      8     45      1      9      0      0      0      0      1      2      3      4      5
 45    add      0      0      1     46      1      9      0      0      0      0      1      2      3      4      5
 46    sto      0      0      4     47      1      9      0      0      0      0      9      2      3      4      5
 47    cal      0      0      2      2     10      9      0      0      0      0      9      2      3      4      5
  2    jmp      0      0     14     14     10      9      0      0      0      0      9      2      3      4      5
 14    inc      0      0      7     15     10     16      0      0      0      0      9      2      3      4      5      0      1      1     48      0      0      0
 15    lod      0      1      4     16     10     16      0      0      0      0      9      2      3      4      5      0      1      1     48      0      0      0
 16    lod      1      1      6     17     10     16      0      0      0      0      9      2      3      4      5      0      1      1     48      0      0      0
 17    add      0      0      1     18     10     16      0      0      0      0      9      2      3      4      5      0      1      1     48      0      0      0
 18    lod      1      2      8     19     10     16      0      0      0      0      9      2      3      4      5      0      1      1     48      0      0      0
 19    add      0      0      1     20     10     16      0      0      0      0      9      2      3      4      5      0      1      1     48      0      0      0
 20    sto      0      0      4     21     10     16      0      0      0      0      9      2      3      4      5      0      1      1     48     16      0      0
 21    cal      0      0      4      4     17     16      0      0      0      0      9      2      3      4      5      0      1      1     48     16      0      0
  4    inc      0      0      6      5     17     22      0      0      0      0      9      2      3      4      5      0      1      1     48     16      0      0      0     10     10     22      0      0
  5    lit      0      0      1      6     17     22      0      0      0      0      9      2      3      4      5      0      1      1     48     16      0      0      0     10     10     22      0      0
  6    sto      0      0      5      7     17     22      0      0      0      0      9      2      3      4      5      0      1      1     48     16      0      0      0     10     10     22      0      1
  7    lod      0      0      4      8     17     22      0      0      0      0      9      2      3      4      5      0      1      1     48     16      0      0      0     10     10     22      0      1
  8    lod      1      0      5      9     17     22      0      0      0      0      9      2      3      4      5      0      1      1     48     16      0      0      0     10     10     22      0      1
  9    add      0      0      1     10     17     22      0      0      0      0      9      2      3      4      5      0      1      1     48     16      0      0      0     10     10     22      0      1
 10    lod      1      3      8     11     17     22      0      0      0      0      9      2      3      4      5      0      1      1     48     16      0      0      0     10     10     22      0      1
 11    add      0      0      1     12     17     22      0      0      0      0      9      2      3      4      5      0      1      1     48     16      0      0      0     10     10     22      0      1
 12    sto      0      2      4     13     17     22      0      0      0      0      5      2      3      4      5      0      1      1     48     16      0      0      0     10     10     22      0      1
 13    rtn      0      0      0     22     10     16      0      0      0      0      5      2      3      4      5      0      1      1     48     16      0      0
 22    rtn      0      0      0     48      1      9      0      0      0      0      5      2      3      4      5
 48    rtn      0      0      0      0      0      0

