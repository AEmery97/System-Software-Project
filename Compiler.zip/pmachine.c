// COP 3402 - Systems Software
// 4-14-17 | Austin Peace & Andrew Emery
// Programming Assignment 1 -- P-Machine

// HEADER.

#include "Compiler.h"

// PROTOTYPES.

void buildMachine(machine* CPU);
int readFile(const char* filename, instruction storage[MAX_CODE_SIZE]);
void interpret(FILE* fptr, instruction storage[MAX_CODE_SIZE], int length, int VmFlag);
void fetch(machine* CPU, instruction* storage);
void execute(machine* CPU, int* stack, int* haltflag, int line, int instructions, int vmFlag);
int base(int l, int base, int* stack);

// GLOBALS.

const char* ISAlit[25] = {"nul", "lit", "rtn", "lod", "sto", "cal", "inc", "jmp", "jpc", "sio", "sio", "sio",
"neg", "add", "sub", "mul", "div", "odd", "mod", "eql", "neq", "lss", "leq", "gtr", "geq"};

// MAIN PROGRAM.

int virtualMachine(const char* filename, int vmFlag) {

    // Main variables.
    machine CPU;
    instruction storage[MAX_CODE_SIZE];
    int* stack = calloc(MAX_STACK_HEIGHT, sizeof(int));
    int endflag = false;
    int num_instructions;
    FILE* fp = fopen("machine.txt", "w");

    // Initialize new instance of CPU.
    buildMachine(&CPU);

    // Read input file.
    num_instructions = readFile(filename, storage);
    if (!num_instructions) return 0;

    // Output interpretation of code.
    interpret(fp, storage, num_instructions, vmFlag);

    // Begin program execution. Track "halt" state after every cycle.
    do {
        fetch(&CPU, storage);
        CPU.PC++;
        execute(&CPU, stack, &endflag, CPU.PC-1, num_instructions, vmFlag);
        if ((CPU.PC == 0 && CPU.BP == 0 && CPU.SP == 0)) endflag = true;

    } while (!endflag);

    fclose(fp);
    free(stack);

    return 1;
}

// FUNCTION DEFINITIONS.
void buildMachine(machine* CPU) {

    // Allocate and initialize the CPU.
    CPU->SP = 0;
    CPU->BP = 1;
    CPU->PC = 0;
    CPU->IR.op = 0;
    CPU->IR.r = 0;
    CPU->IR.l = 0;
    CPU->IR.m = 0;

    CPU->registerFile = calloc(REGFILE_SIZE, sizeof(int));

    return;
}

int readFile(const char* filename, instruction storage[MAX_CODE_SIZE]) {
    // Local variables.
    FILE *fp = NULL;
    int line = 0;

    // Read file (if it is found).
    fp = fopen(filename, "r");
    if (fp == NULL) {
        printf("\nUnable to locate input file. Check local directory.");
        return 0;
    }

    while (!feof(fp)) {
        fscanf(fp, " %d %d %d %d ", &storage[line].op, &storage[line].r, &storage[line].l, &storage[line].m);
        line++;
    }

    return line;
}

void interpret(FILE* fptr, instruction storage[MAX_CODE_SIZE], int length, int VmFlag) {
    // Local variables.
    int n;

    if (fptr == NULL) {
        printf("\nERROR: Machine failed to initialize output file.\n");
    }

    // Print header.
    fprintf(fptr, "%4s %8s %8s %8s %8s\n", "LINE", "OP", "R", "L", "M");
    if (VmFlag) printf("\n\n%4s %8s %8s %8s %8s\n", "LINE", "OP", "R", "L", "M");

    // Print until all code in storage has been read.
    for (n = 0; n < length; n++) {
        fprintf(fptr, "%4d %8s %8d %8d %8d\n", n, ISAlit[storage[n].op], storage[n].r, storage[n].l, storage[n].m);
        if (VmFlag) printf("%4d %8s %8d %8d %8d\n", n, ISAlit[storage[n].op], storage[n].r, storage[n].l, storage[n].m);
    }

    printf("\n\nInitial Values %24s %6s %6s", "pc", "bp", "sp");

    return;
}

void fetch(machine* CPU, instruction* storage) {

    // Retrieve next instruction, according to program counter.
    CPU->IR.op = storage[CPU->PC].op;
    CPU->IR.r = storage[CPU->PC].r;
    CPU->IR.l = storage[CPU->PC].l;
    CPU->IR.m = storage[CPU->PC].m;

    return;
}

void execute(machine* CPU, int* stack, int* haltflag, int line, int instructions, int vmFlag) {
    // Local variables.

    // Execute designated instruction in CPU.
    switch(CPU->IR.op) {

        // LIT.
        case 1:
            CPU->registerFile[CPU->IR.r] = CPU->IR.m;
            break;

        // RTN.
        case 2:
            CPU->SP = CPU->BP - 1;
            CPU->BP = stack[CPU->SP+3];
            CPU->PC = stack[CPU->SP+4];
            break;

        // LOD.
        case 3:
            CPU->registerFile[CPU->IR.r] = stack[base(CPU->IR.l, CPU->BP, stack) + CPU->IR.m];
            break;

        // STO.
        case 4:
            stack[base(CPU->IR.l, CPU->BP, stack) + CPU->IR.m] = CPU->registerFile[CPU->IR.r];
            break;

        // CAL.
        case 5:
            stack[CPU->SP+1] = 0;
            stack[CPU->SP+2] = base(CPU->IR.l, CPU->BP, stack);
            stack[CPU->SP+3] = CPU->BP;
            stack[CPU->SP+4] = CPU->PC;
            CPU->BP = CPU->SP+1;
            CPU->PC = CPU->IR.m;
            break;

        // INC.
        case 6:
            CPU->SP += CPU->IR.m;
            break;

        // JMP.
        case 7:
            CPU->PC = CPU->IR.m;
            break;

        // JPC.
        case 8:
            if (CPU->registerFile[CPU->IR.r] == 0) CPU->PC = CPU->IR.m;
            break;

        // SIO1.
        case 9:
            printf("\nREGISTER %d REPORTS: %d", CPU->IR.r, CPU->registerFile[CPU->IR.r]);
            break;

        // SIO2.
        case 10:
            printf("\nEnter #: ");
            scanf("%d", &CPU->registerFile[CPU->IR.r]);
            break;

        // SIO3.
        case 11:
            *haltflag = 0;
            break;

        // NEG.
        case 12:
            CPU->registerFile[CPU->IR.r] = -CPU->registerFile[CPU->IR.l];
            break;

        // ADD.
        case 13:
            CPU->registerFile[CPU->IR.r] = CPU->registerFile[CPU->IR.l] + CPU->registerFile[CPU->IR.m];
            break;

        // SUB.
        case 14:
            CPU->registerFile[CPU->IR.r] = CPU->registerFile[CPU->IR.l] - CPU->registerFile[CPU->IR.m];
            break;

        // MUL.
        case 15:
            CPU->registerFile[CPU->IR.r] = CPU->registerFile[CPU->IR.l] * CPU->registerFile[CPU->IR.m];
            break;

        // DIV.
        case 16:
            CPU->registerFile[CPU->IR.r] = CPU->registerFile[CPU->IR.l] / CPU->registerFile[CPU->IR.m];
            break;

        // ODD.
        case 17:
            CPU->registerFile[CPU->IR.r] = CPU->registerFile[CPU->IR.r] % 2;
            break;

        // MOD.
        case 18:
            CPU->registerFile[CPU->IR.r] = CPU->registerFile[CPU->IR.l] % CPU->registerFile[CPU->IR.m];
            break;

        // EQL.
        case 19:
            if (CPU->registerFile[CPU->IR.l] == CPU->registerFile[CPU->IR.m]) CPU->registerFile[CPU->IR.r] = 1;
            else CPU->registerFile[CPU->IR.r] = 0;
            break;

        // NEQ.
        case 20:
            if (CPU->registerFile[CPU->IR.l] != CPU->registerFile[CPU->IR.m]) CPU->registerFile[CPU->IR.r] = 1;
            else CPU->registerFile[CPU->IR.r] = 0;
            break;

        // LSS.
        case 21:
            if (CPU->registerFile[CPU->IR.l] < CPU->registerFile[CPU->IR.m]) CPU->registerFile[CPU->IR.r] = 1;
            else CPU->registerFile[CPU->IR.r] = 0;
            break;

        // LEQ.
        case 22:
            if (CPU->registerFile[CPU->IR.l] <= CPU->registerFile[CPU->IR.m]) CPU->registerFile[CPU->IR.r] = 1;
            else CPU->registerFile[CPU->IR.r] = 0;
            break;

        // GTR.
        case 23:
            if (CPU->registerFile[CPU->IR.l] > CPU->registerFile[CPU->IR.m]) CPU->registerFile[CPU->IR.r] = 1;
            else CPU->registerFile[CPU->IR.r] = 0;
            break;

        // GEQ.
        case 24:
            if (CPU->registerFile[CPU->IR.l] >= CPU->registerFile[CPU->IR.m]) CPU->registerFile[CPU->IR.r] = 1;
            else CPU->registerFile[CPU->IR.r] = 0;
            break;

        // ERROR.
        default:
        break;

    }
    // Check state of the VM (finished after this instruction?).
    if (CPU->PC >= instructions || CPU->IR.op == sio3) {
        CPU->PC = 0;
        CPU->SP = 0;
        CPU->BP = 0;
        *haltflag = true;
    }

    if(vmFlag)
    {
        // Print current state of the machine.
        printf("\n%3d %6s %6d %6d %6d %6d %6d %6d", line, ISAlit[CPU->IR.op], CPU->IR.r, CPU->IR.l, CPU->IR.m, CPU->PC, CPU->BP, CPU->SP);

        // Print stack for current instruction.
        int i;
        for (i = 1; i <= CPU->SP; i++) {
            printf(" %6d", stack[i]);
        }
    }


    return;
}

// BORROWED FROM RUBRIC:
int base(int l, int base, int* stack) // l stand for L in the instruction format
{
  int b1; //find base L levels down
  b1 = base;
  while (l > 0)
  {
    b1 = stack[b1 + 1];
    l--;
  }

  return b1;
}

